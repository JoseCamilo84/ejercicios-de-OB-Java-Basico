package com.sesion1.InterfaceDeber;

public interface CocheCRUD {
    void save();
    void findAll();
    void delete();
}
